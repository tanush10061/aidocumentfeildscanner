import gradio as gr
import requests

BACKEND_URL = "http://127.0.0.1:8000/extract_invoice/"

def process_invoice(file, mode):
    if file is None:
        return {"error": "No file provided"}
    
    try:
        print(f"Processing file: {file}, mode: {mode}")
        print(f"Backend URL: {BACKEND_URL}")
        
        # In Gradio 5.x, file is a filepath string when type="filepath"
        with open(file, "rb") as f:
            files = {"file": f}
            data = {"mode": mode}
            
            print("Sending request to backend...")
            resp = requests.post(BACKEND_URL, files=files, data=data, timeout=60)
            
        print(f"Response status: {resp.status_code}")
        
        if resp.status_code == 200:
            return resp.json()
        else:
            return {
                "error": f"Backend error (status {resp.status_code})",
                "status_code": resp.status_code,
                "response_text": resp.text
            }
            
    except requests.exceptions.ConnectionError as e:
        return {"error": f"Connection failed: {str(e)}", "backend_url": BACKEND_URL}
    except requests.exceptions.Timeout as e:
        return {"error": f"Request timed out: {str(e)}"}
    except Exception as e:
        return {"error": f"Unexpected error: {str(e)}", "type": type(e).__name__}

def clear_output():
    """Clear the JSON output when file or mode changes"""
    return None

def launch_app():
    # Enhanced dynamic CSS: Subtle animations, elegant effects
    custom_css = """
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap');
    
    .gradio-container {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif !important;
        background: linear-gradient(135deg, #faf7f2 0%, #f5f1eb 100%) !important;
        min-height: 100vh;
        background-attachment: fixed;
    }
    
    .main-header {
        text-align: center;
        padding: 25px 0;
        background: linear-gradient(135deg, #6b8e23 0%, #556b2f 50%, #4a5d28 100%);
        color: white;
        border-radius: 16px;
        margin-bottom: 20px;
        box-shadow: 0 8px 32px rgba(107, 142, 35, 0.15);
        position: relative;
        overflow: hidden;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    }
    

    .upload-area {
        background: linear-gradient(145deg, #e8f2d4 0%, #dde8c7 100%) !important;
        border: 2px dashed #6b8e23;
        border-radius: 16px;
        margin: 15px 0;
        padding: 30px;
        text-align: center;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
        backdrop-filter: blur(10px);
        box-shadow: 0 4px 20px rgba(107, 142, 35, 0.08);
    }
    
    /* Force Gradio file upload component backgrounds */
    .gr-file-upload, .gr-upload, div[data-testid="file-upload"] {
        background: linear-gradient(145deg, #e8f2d4 0%, #dde8c7 100%) !important;
    }
    
    /* Force all white Gradio backgrounds to darker green */
    .gr-group, .gr-panel, .gr-box {
        background: linear-gradient(145deg, #e8f2d4 0%, #dde8c7 100%) !important;
    }
    

    .mode-toggle {
        background: linear-gradient(145deg, #e8f2d4 0%, #dde8c7 100%) !important;
        border-radius: 16px;
        padding: 18px;
        border: 1px solid rgba(107, 142, 35, 0.12);
        margin: 15px 0;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 2px 12px rgba(107, 142, 35, 0.05);
    }
    
    /* Force Gradio radio button container backgrounds */
    .gr-radio, .gr-radio-group, div[data-testid="radio"] {
        background: linear-gradient(145deg, #e8f2d4 0%, #dde8c7 100%) !important;
    }
    
    /* Comprehensive radio button styling with orange colors */
    
    /* Force remove all gray backgrounds */
    .gr-radio, .gr-radio-group, div[data-testid="radio"], 
    .gr-radio *, div[data-testid="radio"] *,
    .gradio-radio, .gradio-radio * {
        background: linear-gradient(145deg, #e8f2d4 0%, #dde8c7 100%) !important;
        background-color: transparent !important;
    }
    
    /* Target all possible radio button selectors with orange colors */
    input[type="radio"], 
    .gr-radio input[type="radio"],
    div[data-testid="radio"] input[type="radio"],
    .gradio-radio input[type="radio"],
    .gr-radio label input[type="radio"],
    div[data-testid="radio"] label input[type="radio"] {
        appearance: none !important;
        -webkit-appearance: none !important;
        width: 20px !important;
        height: 20px !important;
        border: 3px solid #ffa726 !important;
        border-radius: 50% !important;
        background: white !important;
        cursor: pointer !important;
        transition: all 0.3s ease !important;
        margin-right: 12px !important;
        position: relative !important;
        outline: none !important;
    }
    
    input[type="radio"]:checked,
    .gr-radio input[type="radio"]:checked,
    div[data-testid="radio"] input[type="radio"]:checked,
    .gradio-radio input[type="radio"]:checked,
    .gr-radio label input[type="radio"]:checked,
    div[data-testid="radio"] label input[type="radio"]:checked {
        background: #ffa726 !important;
        border-color: #ff8a65 !important;
        box-shadow: 0 0 0 3px rgba(255, 167, 38, 0.3) !important;
    }
    
    input[type="radio"]:checked::after,
    .gr-radio input[type="radio"]:checked::after,
    div[data-testid="radio"] input[type="radio"]:checked::after,
    .gradio-radio input[type="radio"]:checked::after,
    .gr-radio label input[type="radio"]:checked::after,
    div[data-testid="radio"] label input[type="radio"]:checked::after {
        content: '' !important;
        position: absolute !important;
        top: 50% !important;
        left: 50% !important;
        transform: translate(-50%, -50%) !important;
        width: 8px !important;
        height: 8px !important;
        background: white !important;
        border-radius: 50% !important;
    }
    
    /* Radio button labels and containers with orange accents */
    .gr-radio label, 
    div[data-testid="radio"] label,
    .gradio-radio label,
    .gr-radio .gr-radio-item,
    div[data-testid="radio"] .gr-radio-item {
        color: #556b2f !important;
        font-weight: 500 !important;
        cursor: pointer !important;
        display: flex !important;
        align-items: center !important;
        padding: 12px 18px !important;
        border-radius: 12px !important;
        transition: all 0.3s ease !important;
        background: linear-gradient(145deg, #e8f2d4 0%, #dde8c7 100%) !important;
        border: 2px solid rgba(255, 167, 38, 0.3) !important;
        margin: 6px 0 !important;
    }
    
    .gr-radio label:hover, 
    div[data-testid="radio"] label:hover,
    .gradio-radio label:hover,
    .gr-radio .gr-radio-item:hover {
        background: linear-gradient(145deg, #e8f2d4 0%, #dde8c7 100%) !important;
        border-color: rgba(255, 167, 38, 0.6) !important;
        transform: translateY(-1px) !important;
        box-shadow: 0 4px 12px rgba(255, 167, 38, 0.2) !important;
    }
    
    /* Selected radio item styling */
    .gr-radio label:has(input:checked),
    div[data-testid="radio"] label:has(input:checked),
    .gr-radio .gr-radio-item.selected {
        background: linear-gradient(145deg, #fff5e6 0%, #ffecd1 100%) !important;
        border-color: #ffa726 !important;
        font-weight: 600 !important;
        box-shadow: 0 4px 16px rgba(255, 167, 38, 0.25) !important;
    }
    

    .extract-button {
        background: linear-gradient(135deg, #6b8e23 0%, #556b2f 50%, #4a5d28 100%) !important;
        border: none !important;
        color: white !important;
        font-weight: 500 !important;
        font-size: 16px !important;
        padding: 14px 40px !important;
        border-radius: 50px !important;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1) !important;
        box-shadow: 0 6px 25px rgba(107, 142, 35, 0.25) !important;
        position: relative !important;
        overflow: hidden !important;
        letter-spacing: 0.5px !important;
    }
    
    .extract-button:active {
        transform: translateY(-1px) scale(0.98) !important;
        transition: all 0.1s ease !important;
    }
    .results-area {
        background: linear-gradient(145deg, #e8f2d4 0%, #dde8c7 100%) !important;
        border-radius: 16px;
        padding: 0;
        box-shadow: 0 6px 25px rgba(107, 142, 35, 0.08);
        height: 100%;
        border: 1px solid rgba(107, 142, 35, 0.12);
        display: flex;
        flex-direction: column;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        backdrop-filter: blur(10px);
    }
    

    
    .results-header {
        background: linear-gradient(135deg, #6b8e23 0%, #556b2f 50%, #4a5d28 100%);
        color: white;
        padding: 15px 20px;
        border-radius: 16px 16px 0 0;
        font-weight: 500;
        text-align: center;
        box-shadow: 0 3px 15px rgba(107, 142, 35, 0.2);
        position: relative;
        overflow: hidden;
        letter-spacing: 0.3px;
    }
    

    .results-content {
        padding: 15px;
        flex-grow: 1;
    }
    .gr-column {
        flex: 1 1 50% !important;
        margin: 0 12px !important;
        transition: all 0.3s ease !important;
    }
    
    .gr-row {
        gap: 24px !important;
        align-items: stretch !important;
    }
    
    /* Subtle entrance animations */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .gradio-container > div {
        animation: fadeInUp 0.6s ease-out;
    }
    
    /* Enhanced JSON output styling with dark gradient text on light background */
    .gr-json, 
    div[data-testid="json"], 
    .json-container,
    .json-viewer {
        border-radius: 12px !important;
        border: 1px solid rgba(107, 142, 35, 0.2) !important;
        transition: all 0.3s ease !important;
        background: linear-gradient(145deg, #e8f2d4 0%, #dde8c7 100%) !important;
        box-shadow: 0 4px 16px rgba(107, 142, 35, 0.1) !important;
        position: relative !important;
    }
    
    /* Target JSON content areas with comprehensive selectors */
    .gr-json pre,
    .gr-json textarea,
    .gr-json code,
    div[data-testid="json"] pre,
    div[data-testid="json"] textarea,
    div[data-testid="json"] code,
    .json-container pre,
    .json-container textarea,
    .json-viewer pre,
    .json-viewer textarea {
        background: linear-gradient(145deg, #e8f2d4 0%, #dde8c7 100%) !important;
        color: linear-gradient(135deg, #2d3748 0%, #4a5568 50%, #2d3748 100%) !important;
        background-color: transparent !important;
        padding: 20px !important;
        border-radius: 10px !important;
        margin: 0 !important;
        font-family: 'Fira Code', 'Monaco', 'Menlo', monospace !important;
        font-size: 13px !important;
        line-height: 1.7 !important;
        white-space: pre-wrap !important;
        word-wrap: break-word !important;
        border: none !important;
        resize: none !important;
        font-weight: 500 !important;
    }
    
    /* Apply light orange text to main JSON elements */
    .gr-json,
    .gr-json *,
    div[data-testid="json"],
    div[data-testid="json"] *,
    .json-container,
    .json-container *,
    .json-viewer,
    .json-viewer * {
        color: #ff9f43 !important;
        font-weight: 600 !important;
        text-shadow: 0 1px 2px rgba(255, 159, 67, 0.3) !important;
    }
    
    /* Custom JSON styling */
    .gr-json pre,
    div[data-testid="json"] pre,
    .json-container pre,
    .json-viewer pre {
        font-family: 'Fira Code', 'Monaco', 'Menlo', monospace !important;
        line-height: 1.6 !important;
    }
    
    /* Force navy blue for line items - using CSS approach with higher specificity */
    .line-item-content,
    .line-item-property,
    .object-content,
    .navy-blue-text {
        color: #1a237e !important;
        font-weight: 600 !important;
    }
    
    /* Target specific line item patterns with CSS */
    .gr-json *[class*="line"],
    .gr-json *[class*="item"],
    .gr-json *[class*="object"] {
        color: #1a237e !important;
    }
    
    /* Enhanced navy blue styling with maximum specificity */
    .gr-json .navy-blue-item,
    .gr-json .navy-blue-item *,
    div[data-testid="json"] .navy-blue-item,
    div[data-testid="json"] .navy-blue-item *,
    .json-container .navy-blue-item,
    .json-container .navy-blue-item *,
    .navy-blue-item {
        color: #1a237e !important;
        font-weight: 600 !important;
    }
    
    /* Force all spans and elements with navy class to be navy blue */
    span.navy-blue,
    .navy-blue,
    .navy-blue * {
        color: #1a237e !important;
        font-weight: 600 !important;
    }
    
    /* Override any orange text that should be navy blue in line items */
    .gr-json [style*="color: #ff9f43"].navy-blue-item,
    div[data-testid="json"] [style*="color: #ff9f43"].navy-blue-item {
        color: #1a237e !important;
    }
    
    /* Target line numbers 9, 15, 21, 27, 33, 39 specifically for line items */
    .gr-json .line-9,
    .gr-json .line-15, 
    .gr-json .line-21,
    .gr-json .line-27,
    .gr-json .line-33,
    .gr-json .line-39,
    div[data-testid="json"] .line-9,
    div[data-testid="json"] .line-15,
    div[data-testid="json"] .line-21,
    div[data-testid="json"] .line-27,
    div[data-testid="json"] .line-33,
    div[data-testid="json"] .line-39 {
        color: #1a237e !important;
        font-weight: 600 !important;
    }
    
    /* Nuclear option - override ALL orange colors in JSON containers and make them navy */
    .gr-json *[style*="#ff9f43"],
    .gr-json *[style*="color: #ff9f43"],
    div[data-testid="json"] *[style*="#ff9f43"],
    div[data-testid="json"] *[style*="color: #ff9f43"],
    textarea[style*="#ff9f43"],
    pre[style*="#ff9f43"] {
        color: #1a237e !important;
        font-weight: 600 !important;
    }
    
    /* Results area positioning for fullscreen icon */
    .results-area {
        position: relative !important;
    }
    
    /* Fullscreen icon positioning - visible on top of results area */
    .json-fullscreen-icon {
        position: absolute !important;
        bottom: 20px !important;
        right: 20px !important;
        width: 40px !important;
        height: 40px !important;
        background: linear-gradient(135deg, #ffa726 0%, #ff8a65 100%) !important;
        border: 3px solid white !important;
        border-radius: 50% !important;
        cursor: pointer !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-size: 16px !important;
        color: white !important;
        z-index: 5000 !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 6px 20px rgba(255, 167, 38, 0.5) !important;
        font-weight: bold !important;
        margin-top: -50px !important;
    }
    
    .json-fullscreen-icon:hover {
        transform: scale(1.15) !important;
        box-shadow: 0 6px 20px rgba(255, 167, 38, 0.6) !important;
        background: linear-gradient(135deg, #ff8a65 0%, #ffa726 100%) !important;
        border-color: #fff !important;
    }
    
    .json-fullscreen-icon:active {
        transform: scale(1.05) !important;
        transition: all 0.1s ease !important;
    }
    

    
    /* Fullscreen modal styling */
    .json-fullscreen-modal {
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        width: 100vw !important;
        height: 100vh !important;
        background: rgba(0, 0, 0, 0.95) !important;
        z-index: 9999 !important;
        display: none !important;
        padding: 20px !important;
        box-sizing: border-box !important;
    }
    
    .json-fullscreen-content {
        width: 100% !important;
        height: 100% !important;
        background: linear-gradient(145deg, #1a202c 0%, #2d3748 100%) !important;
        border-radius: 12px !important;
        padding: 30px !important;
        box-sizing: border-box !important;
        overflow: auto !important;
        position: relative !important;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5) !important;
    }
    
    .json-fullscreen-close {
        position: absolute !important;
        top: 15px !important;
        right: 20px !important;
        background: #e53e3e !important;
        border: none !important;
        color: white !important;
        padding: 10px 15px !important;
        border-radius: 6px !important;
        cursor: pointer !important;
        font-size: 14px !important;
        font-weight: 500 !important;
        transition: all 0.3s ease !important;
    }
    
    .json-fullscreen-close:hover {
        background: #c53030 !important;
        transform: translateY(-1px) !important;
    }
    
    .json-fullscreen-text {
        color: #e2e8f0 !important;
        font-family: 'Fira Code', 'Monaco', 'Menlo', monospace !important;
        font-size: 14px !important;
        line-height: 1.8 !important;
        white-space: pre-wrap !important;
        word-wrap: break-word !important;
        margin-top: 50px !important;
    }
    
    /* Comprehensive Gradio background overrides */
    div[data-testid="column"], 
    div[data-testid="block"], 
    div[data-testid="group"],
    .gr-form,
    .gr-column,
    .gr-row,
    .gradio-container div:not(.main-header):not(.results-header) {
        background: linear-gradient(145deg, #e8f2d4 0%, #dde8c7 100%) !important;
    }
    
    /* Specific file upload area */
    div[data-testid="file"] > div,
    div[data-testid="file"] .upload-container,
    .file-upload-area {
        background: linear-gradient(145deg, #e8f2d4 0%, #dde8c7 100%) !important;
    }
    

    
    /* Custom scrollbar */
    ::-webkit-scrollbar {
        width: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: #dde8c7;
        border-radius: 4px;
    }
    
    ::-webkit-scrollbar-thumb {
        background: linear-gradient(135deg, #6b8e23, #556b2f);
        border-radius: 4px;
    }
    

    
    /* Subtle pulsing effect for processing state */
    @keyframes pulse {
        0%, 100% {
            opacity: 1;
        }
        50% {
            opacity: 0.7;
        }
    }
    
    .processing {
        animation: pulse 2s infinite;
    }
    
    /* Static pink and orange gradient for title */
    .gradient-title {
        background: linear-gradient(135deg, #ff6b9d 0%, #ffa726 50%, #ff8a65 100%);
        -webkit-background-clip: text !important;
        -webkit-text-fill-color: transparent !important;
        background-clip: text !important;
        filter: brightness(1.1) saturate(1.0) !important;
    }
    """
    
    # Olive green theme with warm cream background
    olive_theme = gr.themes.Base(
        primary_hue="green",
        secondary_hue="green",
        neutral_hue="stone",
    ).set(
        body_background_fill="#faf7f2",
        block_background_fill="#e8f2d4",
        panel_background_fill="#e8f2d4",
        background_fill_primary="#faf7f2",
        background_fill_secondary="#dde8c7"
    )
    
    with gr.Blocks(css=custom_css, title="Invoice OCR", theme=olive_theme) as demo:
        gr.HTML("""
        <div class="main-header">
            <h1 class="gradient-title" style="margin: 0; font-size: 2.4em; font-weight: 400; letter-spacing: -0.5px; text-shadow: 0 2px 4px rgba(0,0,0,0.3);">Invoice OCR</h1>
            <p style="margin: 12px 0 0 0; font-size: 1.1em; opacity: 0.95; color: white; font-weight: 300; letter-spacing: 0.3px;">AI-powered document data extraction</p>
        </div>
        """)
        
        with gr.Row():
            with gr.Column(scale=1):
                with gr.Group(elem_classes=["results-area"]):
                    gr.HTML("""<div class="results-header">Upload Your Invoice</div>""")
                    with gr.Group(elem_classes=["results-content"]):
                        file_input = gr.File(
                            label="",
                            file_count="single",
                            type="filepath",
                            file_types=[".pdf", ".png", ".jpg", ".jpeg"],
                            elem_classes=["upload-area"],
                            show_label=False
                        )
                        gr.HTML("""<div style="text-align: center; padding: 10px; color: #6b8e23; font-size: 0.9em;"><strong>PDF, PNG, JPG, JPEG • Max 10MB</strong></div>""")
                        
                        with gr.Group(elem_classes=["mode-toggle"]):
                            mode = gr.Radio(
                                choices=[("AI (High Accuracy)", "paid"), ("OCR (Fast & Free)", "open_source")],
                                value="paid",
                                label="Processing Mode",
                                container=False
                            )
                        
                        submit = gr.Button(
                            "Extract Data",
                            variant="primary",
                            elem_classes=["extract-button"]
                        )
            
            with gr.Column(scale=1):
                with gr.Group(elem_classes=["results-area"]):
                    gr.HTML("""<div class="results-header">Extracted Invoice Data</div>""")
                    with gr.Group(elem_classes=["results-content"]):
                        output = gr.JSON(
                            label="",
                            show_label=False,
                            height=280,
                            elem_id="json-output"
                        )
                    
                    # Add fullscreen icon positioned outside results-content but inside results-area
                    gr.HTML("""
                    <div class="json-fullscreen-icon" onclick="toggleFullscreen()" title="View Fullscreen" style="display: flex;">
                        🔍
                    </div>
                    """)
        
        def process_with_status(file, mode):
            if file is None:
                return {"error": "No file provided"}
            result = process_invoice(file, mode)
            return result
        
        # Add fullscreen modal and JavaScript
        gr.HTML(r"""
        <!-- Fullscreen Modal -->
        <div id="json-fullscreen-modal" class="json-fullscreen-modal">
            <div class="json-fullscreen-content">
                <button class="json-fullscreen-close" onclick="closeFullscreen()">✕ Close</button>
                <h2 style="color: #e2e8f0; margin-top: 50px; margin-bottom: 20px; font-family: 'Inter', sans-serif;">Invoice JSON Data</h2>
                <pre id="fullscreen-json-text" class="json-fullscreen-text"></pre>
            </div>
        </div>
        
        <script>
        function applyJsonSyntaxHighlighting() {
            console.log('Running JSON syntax highlighting...');
            
            // NUCLEAR OPTION: Make EVERYTHING navy blue first, then selectively make main properties orange
            const jsonContainers = document.querySelectorAll('#json-output, [data-testid="json"], .gr-json, textarea, pre');
            
            jsonContainers.forEach(container => {
                console.log('Processing container:', container);
                
                const fullText = container.textContent || container.innerText || container.value || '';
                
                if (fullText.includes('line_items') || fullText.includes('Object(')) {
                    console.log('Found JSON with line items - applying NAVY BLUE to everything!');
                    
                    // STEP 1: Make EVERYTHING navy blue
                    container.style.setProperty('color', '#1a237e', 'important');
                    container.style.setProperty('font-weight', '600', 'important');
                    
                    // Style all child elements navy blue
                    const allChildren = container.querySelectorAll('*');
                    allChildren.forEach(child => {
                        child.style.setProperty('color', '#1a237e', 'important');
                        child.style.setProperty('font-weight', '600', 'important');
                    });
                    
                    // STEP 2: Selectively make main invoice properties orange (NOT line items)
                    allChildren.forEach(element => {
                        const text = element.textContent || element.innerText || '';
                        
                        // Only make these specific main properties orange
                        if (text.includes('"invoice_data"') || 
                            text.includes('"vendor_name"') || 
                            text.includes('"invoice_number"') ||
                            text.includes('"invoice_date"') ||
                            text.includes('"due_date"') ||
                            text.includes('"bill_to"') ||
                            text.includes('"grand_total"') ||
                            text.includes('"tax_amount"') ||
                            text.includes('"subtotal"')) {
                            
                            // Only make these orange if they're NOT part of line items
                            if (!text.includes('Object(') && !text.includes('description') && !text.includes('quantity')) {
                                console.log('Making main property orange:', text.substring(0, 30));
                                element.style.setProperty('color', '#ff9f43', 'important');
                                element.style.setProperty('font-weight', '600', 'important');
                            }
                        }
                    });
                    
                    console.log('Successfully applied navy blue to all line items!');
                }
            });
            
            // Additional approach: Use CSS to override
            const style = document.createElement('style');
            style.textContent = `
                .navy-blue-item,
                .navy-blue-item * {
                    color: #1a237e !important;
                    font-weight: 600 !important;
                }
                
                /* Target any element containing Object( */
                *:contains("Object(") {
                    color: #1a237e !important;
                }
                
                /* Force override any existing orange colors in JSON */
                .gr-json *[style*="#ff9f43"],
                [data-testid="json"] *[style*="#ff9f43"] {
                    color: #1a237e !important;
                }
            `;
            
            if (!document.head.querySelector('#navy-blue-override')) {
                style.id = 'navy-blue-override';
                document.head.appendChild(style);
            }
        }
        
        function toggleFullscreen() {
            console.log('Fullscreen clicked!');
            // Get JSON content from the Gradio output
            setTimeout(() => {
                const jsonElements = document.querySelectorAll('#json-output textarea, #json-output pre, textarea, pre, .json-container, [data-testid="json"]');
                let jsonText = '';
                
                console.log('Found elements:', jsonElements.length);
                
                for (let elem of jsonElements) {
                    const text = elem.value || elem.textContent || elem.innerText || '';
                    console.log('Element text:', text.substring(0, 100));
                    if (text.trim() && (text.includes('{') || text.includes('['))) {
                        jsonText = text;
                        break;
                    }
                }
                
                if (!jsonText || jsonText.trim() === '' || jsonText.trim() === 'null') {
                    alert('No JSON data to display in fullscreen');
                    return;
                }
                
                // Try to format JSON if it's valid
                try {
                    const parsed = JSON.parse(jsonText);
                    jsonText = JSON.stringify(parsed, null, 2);
                } catch (e) {
                    console.log('JSON parse error, using raw text');
                }
                
                document.getElementById('fullscreen-json-text').textContent = jsonText;
                document.getElementById('json-fullscreen-modal').style.display = 'block';
                document.body.style.overflow = 'hidden';
            }, 100);
        }
        
        function closeFullscreen() {
            document.getElementById('json-fullscreen-modal').style.display = 'none';
            document.body.style.overflow = 'auto';
        }
        
        // Close on escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeFullscreen();
            }
        });
        
        // Apply syntax highlighting when content changes - very frequent
        setInterval(() => {
            applyJsonSyntaxHighlighting();
            forceNavyBlueLineItems();
        }, 100);
        
        // Apply highlighting immediately and repeatedly on page load
        setTimeout(applyJsonSyntaxHighlighting, 100);
        setTimeout(applyJsonSyntaxHighlighting, 500);
        setTimeout(applyJsonSyntaxHighlighting, 1000);
        setTimeout(applyJsonSyntaxHighlighting, 2000);
        setTimeout(applyJsonSyntaxHighlighting, 3000);
        setTimeout(applyJsonSyntaxHighlighting, 5000);
        
        // Additional brute force function specifically for line items
        function forceNavyBlueLineItems() {
            console.log('Running brute force navy blue application...');
            
            // Target all possible JSON containers
            const containers = document.querySelectorAll('textarea, pre, .gr-json, [data-testid="json"], #json-output');
            
            containers.forEach(container => {
                const text = container.value || container.textContent || container.innerText || '';
                
                if (text.includes('line_items') || text.includes('Object(')) {
                    console.log('Found JSON with line items, applying navy blue...');
                    
                    // Apply navy blue to the entire container if it contains line items
                    if (text.includes('Object(4)') || text.includes('description') || text.includes('quantity')) {
                        container.style.setProperty('color', '#1a237e', 'important');
                        container.style.setProperty('font-weight', '600', 'important');
                        
                        // Also style any parent elements
                        let parent = container.parentElement;
                        while (parent) {
                            if (parent.classList.contains('gr-json') || parent.getAttribute('data-testid') === 'json') {
                                parent.style.setProperty('color', '#1a237e', 'important');
                                break;
                            }
                            parent = parent.parentElement;
                        }
                    }
                }
            });
            
            // Direct DOM manipulation - find and style elements with Object patterns
            document.querySelectorAll('*').forEach(el => {
                const text = el.textContent || '';
                if (text.includes('Object(4)') || 
                    text.includes('► { Object(4) }') ||
                    text.match(/►.*Object\(\d+\)/)) {
                    console.log('Found Object pattern, forcing navy blue:', text.substring(0, 30));
                    el.style.setProperty('color', '#1a237e', 'important');
                    el.style.setProperty('font-weight', '600', 'important');
                }
            });
        }
        
        // Also apply when DOM changes
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList' || mutation.type === 'characterData') {
                    setTimeout(applyJsonSyntaxHighlighting, 100);
                }
            });
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true,
            characterData: true
        });
        </script>
        """)

        submit.click(fn=process_with_status, inputs=[file_input, mode], outputs=[output])
        file_input.change(fn=clear_output, inputs=[], outputs=output)
        mode.change(fn=clear_output, inputs=[], outputs=output)
        
    demo.launch()

if __name__ == '__main__':
    launch_app()